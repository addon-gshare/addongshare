# Cloning Project

cfscrape is pulled in through a submodule so you'll need to setup the submodule
when cloning this repository

```
git clone https://github.com/jdollar/script.module.cfscrape.git
git submodule init
git submodule update
```
