#!/usr/bin/python
#coding=utf-8

import xbmc, xbmcaddon

addon = xbmcaddon.Addon(id='plugin.video.salemmax.livestream')

if addon.getSetting('autostart') == 'true':
	xbmc.executebuiltin("RunAddon()")