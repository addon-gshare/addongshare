import xbmcaddon

MainBase = 'aHR0cHM6Ly9nb28uZ2wvNmJrOUtN'.decode('base64')
addon = xbmcaddon.Addon('plugin.video.salemmax.moviehd')