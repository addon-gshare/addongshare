#!/usr/bin/python
# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import urllib , requests , re , os , json , uuid , kodi4vn , cfscrape
import concurrent . futures
from kodiswift import Plugin
from kodi_six import xbmc , xbmcgui
from operator import itemgetter
from cookielib import LWPCookieJar
requests . packages . urllib3 . disable_warnings ( )
if 64 - 64: i11iIiiIii
OO0o = Plugin ( )
Oo0Ooo = cfscrape . create_scraper ( )
Oo0Ooo . cookies = LWPCookieJar ( )
if 85 - 85: OOO0O0O0ooooo % IIii1I . II1 - O00ooooo00
I1IiiI = "https://docs.google.com/drawings/d/12OjbFr3Z5TCi1WREwTWECxNNwx0Kx-FTrCLOigrpqG4/pub?w=256&h=256"
IIi1IiiiI1Ii = "https://docs.google.com/drawings/d/1rniOY_omlvmXtpuHFoMuCS3upWOu04DD0KWRyLV4szs/pub?w=1920&h=1080"
I11i11Ii = "plugin://plugin.video.kodi4vn.vkool"
oO00oOo = I11i11Ii . split ( "/" ) [ - 1 ]
OOOo0 = '<li class="movie-item"><a[^>]*title="(.+?)" href="(.+?)">.+?url\((.+?)\).+?<span class="ribbon">(.*?)</span>'
Oooo000o = 36
if 6 - 6: i1 * ii1IiI1i % OOooOOo / I11i / o0O / IiiIII111iI
IiII = {
 'Referer' : 'http://vkool.net/' ,
 'Content-Type' : 'application/x-www-form-urlencoded'
 }
if 28 - 28: Ii11111i * iiI1i1
@ OO0o . route ( '/' )
def i1I1ii1II1iII ( ) :
 xbmc . executebuiltin ( "ShowPicture({0})" . format ( IIi1IiiiI1Ii ) )
 if 86 - 86: oO0o
@ OO0o . route ( '/search' )
def IIII ( ) :
 Oo0oO0oo0oO00 = OO0o . keyboard ( heading = 'Tìm kiếm' )
 if Oo0oO0oo0oO00 :
  i111I = 'http://vkool.net/search/' + urllib . quote_plus ( Oo0oO0oo0oO00 ) + '/%s.html'
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "a" ) as II1Ii1iI1i :
   II1Ii1iI1i . write ( Oo0oO0oo0oO00 + "\n" )
  iiI1iIiI = {
 "title" : "Search: {0}" . format ( Oo0oO0oo0oO00 ) ,
 "url" : i111I ,
 "page" : 1
 }
  OOo = '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OO0o . redirect ( OOo )
  if 1 - 1: IIii11I1 - i1111 - i1IIi11111i / I11i1i11i1I % Iiii
@ OO0o . route ( '/searchlist' )
def OOO0O ( ) :
 oo0ooO0oOOOOo = [ ]
 oO000OoOoo00o = [ {
 "label" : "[B]Search[/B]" ,
 "path" : "{0}/search" . format ( I11i11Ii ) ,
 "thumbnail" : "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
 } ]
 iiiI11 = [ ]
 if os . path . exists ( kodi4vn . SEARCH_HISTORY_PATH ) :
  with open ( kodi4vn . SEARCH_HISTORY_PATH , "r" ) as II1Ii1iI1i :
   iiiI11 = II1Ii1iI1i . read ( ) . strip ( ) . split ( "\n" )
  for OOooO in reversed ( iiiI11 ) :
   i111I = 'http://vkool.net/search/' + urllib . quote_plus ( OOooO ) + '/%s.html'
   iiI1iIiI = {
 "title" : "Search: {0}" . format ( OOooO ) ,
 "url" : i111I ,
 "page" : 1
 }
   OOoO00o = { }
   OOoO00o [ "label" ] = OOooO
   OOoO00o [ "path" ] = "{0}/list_media/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
   OOoO00o [ "thumbnail" ] = "https://docs.google.com/drawings/d/1uP5xm3I5KRZsnoliqJDkYJXYz1MznecVqWg3e-Gue48/pub?w=256&h=256"
   oo0ooO0oOOOOo . append ( OOoO00o )
 oo0ooO0oOOOOo = oO000OoOoo00o + oo0ooO0oOOOOo
 OO0o . set_content ( "files" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 9 - 9: I1iiiiI1iII - oO0o / O00ooooo00 + oO0o
@ OO0o . route ( '/list_media/<args_json>' )
def IiIi1Iii1I1 ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MEDIA , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] % O00O0O0O0 [ "page" ] , session = Oo0Ooo )
 oo = kodi4vn . cleanHTML ( ooO0O . text )
 iii11iII = re . compile ( OOOo0 , re . S ) . findall ( oo )
 for i1I111I , i111I , i11I1IIiiIi , IiIiIi in iii11iII :
  i1I111I = "{0} ({1})" . format ( i1I111I , IiIiIi )
  iiI1iIiI = {
 "title" : i1I111I ,
 "quality_label" : IiIiIi ,
 "url" : i111I
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = i1I111I
  OOoO00o [ "path" ] = "{0}/list_mirrors/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OOoO00o [ "thumbnail" ] = i11I1IIiiIi
  if "HD" in IiIiIi :
   OOoO00o [ "label" ] = "[COLOR yellow]{0}[/COLOR]" . format ( OOoO00o [ "label" ] )
  oo0ooO0oOOOOo . append ( OOoO00o )
 if len ( oo0ooO0oOOOOo ) == Oooo000o :
  II = int ( O00O0O0O0 [ "page" ] ) + 1
  O00O0O0O0 [ "page" ] = II
  oo0ooO0oOOOOo . append ( {
 'label' : 'Next >>' ,
 'thumbnail' : I1IiiI ,
 'path' : '{0}/list_media/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( O00O0O0O0 ) )
 ) ,
 } )
 OO0o . set_content ( "movies" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 14 - 14: OOooOOo . ii1IiI1i / i1111
@ OO0o . route ( '/list_mirrors/<args_json>' )
def IiiiI1II1I1 ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_MIRROR , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] , session = Oo0Ooo )
 ooIi11iI1i = re . search ( '<a id="btn-film-watch"[^>]*href="(.+?)">Xem phim</a>' , ooO0O . text ) . group ( 1 )
 ooO0O = kodi4vn . Request ( ooIi11iI1i , session = Oo0Ooo )
 oo = kodi4vn . cleanHTML ( ooO0O . text )
 for Ooo in re . compile ( '<div class="listserver"><div[^>]*><img[^>]*/>(.+?)(<img[^>]*/>)*</div>.+?</div></div>' ) . findall ( oo ) :
  iiI1iIiI = {
 "title" : O00O0O0O0 [ "title" ] ,
 "mirror" : Ooo [ 0 ] ,
 "quality_label" : O00O0O0O0 [ "quality_label" ] ,
 "url" : ooIi11iI1i
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = Ooo [ 0 ]
  OOoO00o [ "path" ] = "{0}/list_eps/{1}" . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  oo0ooO0oOOOOo . append ( OOoO00o )
 OO0o . set_content ( "files" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 68 - 68: IIii11I1 + oO0o . IIii1I - I11i1i11i1I % IIii1I - I1iiiiI1iII
@ OO0o . route ( '/list_eps/<args_json>' )
def oOOO00o ( args_json = { } ) :
 oo0ooO0oOOOOo = [ ]
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_EPS , O00O0O0O0 )
 ooO0O = kodi4vn . Request ( O00O0O0O0 [ "url" ] , session = Oo0Ooo )
 oo = kodi4vn . cleanHTML ( ooO0O . text )
 O0O00o0OOO0 = '<div class="listserver"><div[^>]*><img[^>]*/>\s*{0}.+?(<img[^>]*/>)*</div>(.+?)</div></div>' . format ( O00O0O0O0 [ "mirror" ] . replace ( ":" , "" ) . strip ( ) )
 ooIi11iI1i = re . search ( O0O00o0OOO0 , oo ) . group ( 0 )
 for Ii1iIIIi1ii , o0oo0o0O00OO in re . compile ( '<a[^>]*href="(.+?)"[^>]*>(.+?)</a>' ) . findall ( ooIi11iI1i ) :
  if not Ii1iIIIi1ii . startswith ( "http" ) :
   Ii1iIIIi1ii = "http://vkool.net/{0}" . format ( Ii1iIIIi1ii )
  iiI1iIiI = {
 "title" : O00O0O0O0 [ "title" ] ,
 "quality_label" : O00O0O0O0 [ "quality_label" ] ,
 "mirror" : O00O0O0O0 [ "mirror" ] ,
 "url" : Ii1iIIIi1ii ,
 "eps" : o0oo0o0O00OO
 }
  OOoO00o = { }
  OOoO00o [ "label" ] = "Part {0} - {1} [{2}]" . format (
 o0oo0o0O00OO ,
 O00O0O0O0 [ "title" ] ,
 O00O0O0O0 [ "mirror" ] . replace ( ":" , "" )
 )
  OOoO00o [ "path" ] = '{0}/play/{1}' . format (
 I11i11Ii ,
 urllib . quote_plus ( json . dumps ( iiI1iIiI ) )
 )
  OOoO00o [ "is_playable" ] = True
  if "Download" not in OOoO00o [ "label" ] :
   oo0ooO0oOOOOo . append ( OOoO00o )
 OO0o . set_content ( "episodes" )
 return OO0o . finish ( oo0ooO0oOOOOo )
 if 80 - 80: O00ooooo00
 if 70 - 70: o0O - IiiIII111iI
@ OO0o . route ( '/play/<args_json>' )
def I1iii ( args_json = { } ) :
 O00O0O0O0 = json . loads ( args_json )
 kodi4vn . GA ( oO00oOo , kodi4vn . GA_PLAY , O00O0O0O0 )
 OO0o . set_resolved_url ( i1iiI11I ( O00O0O0O0 [ "url" ] ) )
 if 29 - 29: II1
def i1iiI11I ( url ) :
 ooO0O = kodi4vn . Request ( url , session = Oo0Ooo )
 oo = kodi4vn . cleanHTML ( ooO0O . text )
 iI = "http://vkool.net/js/vkphp/plugins/gkpluginsphp.php"
 try :
  ooIi11iI1i = re . search ( 'link\: *"(.+?)"' , oo ) . group ( 1 )
 except :
  ooIi11iI1i = re . search ( 'gklist\: *"(.+?)"' , oo ) . group ( 1 )
  ooO0O = kodi4vn . Request ( ooIi11iI1i , session = Oo0Ooo )
  oo = ooO0O . text
  ooIi11iI1i = re . search ( '<location><\!\[CDATA\[(.+?)\]' , ooO0O . text ) . group ( 1 )
 I1i1I1II = { "link" : ooIi11iI1i }
 ooO0O = kodi4vn . Request ( iI , additional_headers = IiII , session = Oo0Ooo , data = I1i1I1II )
 i1IiIiiI = ooO0O . json ( )
 try :
  if "openload.co" in i1IiIiiI [ "link" ] :
   return kodi4vn . resolve ( i1IiIiiI [ "link" ] )
 except : pass
 for I1I in i1IiIiiI [ i1IiIiiI . keys ( ) [ 0 ] ] :
  if "1080" not in I1I [ "label" ] :
   url = "aHR0cHM6Ly9lY2hpcHN0b3JlLmNvbS9wYXJzZXIvZGVjcnlwdC92a29vbD9saW5rPQ==" . decode ( "base64" ) + urllib . quote_plus ( I1I [ "link" ] . replace ( '\/' , '/' ) . replace ( '\\/' , '/' ) )
   ooO0O = kodi4vn . Request ( url , session = Oo0Ooo )
   url = ooO0O . text
   oOO00oOO = ""
   if "vkool.life" in url :
    oOO00oOO = "|Referer=http%3A%2F%2Fvkool.net%2Fwatch%2F"
   return url + oOO00oOO
 return None
 if 75 - 75: O00ooooo00 / II1 - OOO0O0O0ooooo / o0O . i1 - O00ooooo00
 if 71 - 71: oO0o + i1111 * oO0o - I11i * IiiIII111iI
if __name__ == '__main__' :
 OO0o . run ( )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
