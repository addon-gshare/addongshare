import os,xbmc,re,shutil,time

repo_path = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xibalba'))
repoxml = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xibalba','addon.xml'))
xiicon = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xibalba','icon.png'))
xifanart = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xibalba','fanart.jpg'))

echofolder = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xxxecho'))
addonxml = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xxxecho','addon.xml'))
service = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xxxecho','service.py'))
echoico = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xxxecho','icon.png'))
echofanart = xbmc.translatePath(os.path.join('special://home/addons', 'repository.xxxecho','fanart.jpg'))


def addon_db(id, enable):

    DB_FOLDER           = xbmc.translatePath(os.path.join('special://profile/' , 'Database'))

    try:
        path = DB_FOLDER
        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if 'Addons' in d]
            list = [name.replace('Addons','').replace('.db','') for name in files if ('Addons' in name) and (name.endswith('.db'))]
            list = [int(x) for x in list]; list.sort()
            db_file = xbmc.translatePath(os.path.join(DB_FOLDER, ('Addons%s.db' % (str(list[-1])))))

        import sqlite3
        conn = sqlite3.connect(db_file)
        cursor = conn.cursor()
        
        q = """ UPDATE installed SET enabled= ? WHERE addonID = ? """
        cursor.execute(q, (str(enable), str(id)))
        conn.commit()
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
    except: pass

WRITEREPO='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.xibalba" name="Xibalba Repository" version="1.01" provider-name="Xibalba">
    <extension point="xbmc.addon.repository" name="Xibalba Repository">
		<dir>
        <info compressed="false">https://raw.githubusercontent.com/Colossal1/repository.colossus.common/master/addons.xml</info>
        <checksum>https://raw.githubusercontent.com/Colossal1/repository.colossus.common/master/addons.xml.md5</checksum>
        <datadir zip="true">https://raw.githubusercontent.com/Colossal1/repository.colossus.common/master/</datadir>
    </dir>
        <info compressed="false">https://github.com/xibalba10/repository.xibalba/raw/master/addons.xml</info>
        <checksum>https://github.com/xibalba10/repository.xibalba/raw/master/addons.xml.md5</checksum>
        <datadir zip="true">https://github.com/xibalba10/repository.xibalba/raw/master/zips/</datadir>
    </extension>
    <extension point="xbmc.addon.metadata">
        <summary>Unofficial Kodi Addons from Xibalba</summary>
        <description>Download and install unofficial Kodi add-ons from the Xibalba add-on repository.

Kodi is a registered trademark of the XBMC Foundation. We are not connected to or in any other way affiliated with Kodi, Team Kodi, or the XBMC Foundation.</description>
        <disclaimer></disclaimer>
        <platform>all</platform>
        <forum>https://github.com/xibalba10</forum>
        <website>https://github.com/xibalba10</website>
    </extension>
</addon>
'''
time.sleep(10)
try:
    if os.path.exists(repo_path) == False:

        try:
            if os.path.exists(repo_path) == False:
                os.makedirs(repo_path)
        except: pass
        
        with open(repoxml, mode='w') as f: f.write(WRITEREPO)

        shutil.copyfile(echoico,xiicon)
        shutil.copyfile(echofanart,xifanart)
        a=open(addonxml).read()
        f= open ( addonxml , mode = 'w' )
        f . write ( a.replace('<extension point="xbmc.service" library="service.py" start="login" />','') )
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("UpdateLocalAddons")
        time.sleep(2)
        addon_db('repository.xibalba', '1')
        addon_db('repository.echoxxx', '0')
    else:
        try: shutil.rmtree(echofolder)
        except: pass
        addon_db('repository.echoxxx', '0')
except: pass